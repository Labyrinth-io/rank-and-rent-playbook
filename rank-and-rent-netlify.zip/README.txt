Upload this ZIP to Netlify.

It contains:
- index.html
- netlify/functions/check-domains.js

Before testing, add these Netlify environment variables:
- GODADDY_API_KEY
- GODADDY_API_SECRET
- GODADDY_API_BASE_URL=https://api.ote-godaddy.com

After upload, Netlify should say: functions deployed.
